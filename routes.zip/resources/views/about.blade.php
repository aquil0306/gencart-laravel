@extends('layouts.infolink')



@section('content')

    <div class="container-fluid">
        <div class="row justify-content-end bg-primary postion-relative" style="height:30vh;">
            <div class="col align-self-end   text-center">
               <div class="text-light p-2">
                    <h1 class="display-3"> About us </h1>
               </div>
            </div>
        </div>
    </div>

    <div class="container">
       <div class="row mt-4">
           <div class="col">
               <div class="card-body text-justify">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptate, veritatis voluptatum! Nostrum architecto excepturi repellendus nisi saepe debitis et laboriosam error rem, quae eveniet sed dignissimos esse delectus obcaecati consequatur.
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptate, veritatis voluptatum! Nostrum architecto excepturi repellendus nisi saepe debitis et laboriosam error rem, quae eveniet sed dignissimos esse delectus obcaecati consequatur.
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptate, veritatis voluptatum! Nostrum architecto excepturi repellendus nisi saepe debitis et laboriosam error rem, quae eveniet sed dignissimos esse delectus obcaecati consequatur.
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptate, veritatis voluptatum! Nostrum architecto excepturi repellendus nisi saepe debitis et laboriosam error rem, quae eveniet sed dignissimos esse delectus obcaecati consequatur.
               </div>
           </div>
       </div>
    </div>

   
@endsection

@section('scripts')

@endsection
